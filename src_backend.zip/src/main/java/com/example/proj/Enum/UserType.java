package com.example.proj.Enum;

public enum UserType {
	ADMIN,
	STUDENT;
}
