package com.example.proj.Enum;

public enum TaskStatus {
    COMPLETED,
    PENDING
}
