package com.example.proj.Entity;

import java.sql.Date;

import com.example.proj.Enum.UserType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY )
	private long user_id;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "user_type", nullable= false) 
	private UserType userType;  // ADMIN or STUDENT
	 
	private String name;
	private String email;
	private String  password;
	private Date enrollment_date;
	private int course_id;


}

