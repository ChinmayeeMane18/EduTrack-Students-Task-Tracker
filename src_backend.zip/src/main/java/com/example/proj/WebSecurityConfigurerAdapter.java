package com.example.proj;

public class WebSecurityConfigurerAdapter {

}
