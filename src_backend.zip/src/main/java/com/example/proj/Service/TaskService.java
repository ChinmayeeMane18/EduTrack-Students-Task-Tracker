package com.example.proj.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.proj.UnauthorizedAccessException;
import com.example.proj.Entity.Task;
import com.example.proj.Entity.User;
import com.example.proj.Enum.TaskStatus;
import com.example.proj.Enum.UserType;
import com.example.proj.Repo.TaskRepository;
import com.example.proj.Repo.UserRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class TaskService {

    @Autowired
    private TaskRepository taskRepository;
    
    @Autowired
    private UserRepository userRepository;

    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    public Optional<Task> getTaskById(Long id) {
        return taskRepository.findById(id);
    }

    public Task createTask(Task task) {
        task.setStatus(TaskStatus.PENDING);
        return taskRepository.save(task);
    }

//    public Task updateTask(Long id, Task updatedTask) {
//        return taskRepository.findById(id).map(task -> {
//        	
//            task.setTitle(updatedTask.getTitle());
//            task.setDescription(updatedTask.getDescription());
//            task.setDueDate(updatedTask.getDueDate());
//            task.setStatus(updatedTask.getStatus());
//            task.setCourseId(updatedTask.getCourseId());
//            return taskRepository.save(task);
//        }).orElse(null);
//    }
    
    public Task updateTask(Long id, Task updatedTask) {
        return taskRepository.findById(id).map(existingTask -> {
            
            existingTask.setTitle(updatedTask.getTitle());
            existingTask.setDescription(updatedTask.getDescription());
            existingTask.setDueDate(updatedTask.getDueDate());
            existingTask.setStartTime(updatedTask.getStartTime());
            existingTask.setEndTime(updatedTask.getEndTime());

            // ✅ Preserve existing status if not provided in the request
            if (updatedTask.getStatus() != null) {
                existingTask.setStatus(updatedTask.getStatus());
            }

            return taskRepository.save(existingTask);
        }).orElseThrow(() -> new EntityNotFoundException("Task not found"));
    }


    public boolean deleteTask(Long id) {
        if (taskRepository.existsById(id)) {
            taskRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public Task startTask(Long id) {
        return taskRepository.findById(id).map(task -> {
            task.setStartTime(LocalDateTime.now());
            return taskRepository.save(task);
        }).orElse(null);
    }

    public Task completeTask(Long id) {
        return taskRepository.findById(id).map(task -> {
            task.setEndTime(LocalDateTime.now());
            task.setStatus(TaskStatus.COMPLETED);
            return taskRepository.save(task);
        }).orElse(null);
    }
}


//@Service
//public class TaskService {
//
//    @Autowired
//    private TaskRepository taskRepository;
//
//    @Autowired
//    private UserRepository userRepository;
//
//    // ✅ Students can only view tasks
//    public List<Task> getAllTasks(Long userId) {
//        User user = userRepository.findById(userId)
//                .orElseThrow(() -> new EntityNotFoundException("User not found"));
//
//        if (user.getUser_Type() == UserType.STUDENT) {
//            return taskRepository.findAll();
//        } else {
//            throw new UnauthorizedAccessException("Students can only view tasks.");
//        }
//    }
//
//    // ✅ Admins can view tasks
//    public List<Task> getAllTasksForAdmin() {
//        return taskRepository.findAll();
//    }
//
//    // ✅ Only Admins can add tasks
//    public Task addTask(Long adminId, Task task) {
//        User admin = userRepository.findById(adminId)
//                .orElseThrow(() -> new EntityNotFoundException("Admin not found"));
//
//        if (admin.getUser_Type() == UserType.ADMIN) {
//            return taskRepository.save(task);
//        } else {
//            throw new UnauthorizedAccessException("Only admins can add tasks.");
//        }
//    }
//
//    // ✅ Only Admins can update tasks
//    public Task updateTask(Long adminId, Long taskId, Task updatedTask) {
//        User admin = userRepository.findById(adminId)
//                .orElseThrow(() -> new EntityNotFoundException("Admin not found"));
//
//        if (admin.getUser_Type() == UserType.ADMIN) {
//            return taskRepository.findById(taskId).map(existingTask -> {
//                existingTask.setTitle(updatedTask.getTitle());
//                existingTask.setDescription(updatedTask.getDescription());
//                existingTask.setDueDate(updatedTask.getDueDate());
//                existingTask.setStartTime(updatedTask.getStartTime());
//                existingTask.setEndTime(updatedTask.getEndTime());
//
//                if (updatedTask.getStatus() != null) {
//                    existingTask.setStatus(updatedTask.getStatus());
//                }
//
//                return taskRepository.save(existingTask);
//            }).orElseThrow(() -> new EntityNotFoundException("Task not found"));
//        } else {
//            throw new UnauthorizedAccessException("Only admins can update tasks.");
//        }
//    }
//
//    // ✅ Only Admins can delete tasks
//    public void deleteTask(Long adminId, Long taskId) {
//        User admin = userRepository.findById(adminId)
//                .orElseThrow(() -> new EntityNotFoundException("Admin not found"));
//
//        if (admin.getUser_Type() == UserType.ADMIN) {
//            taskRepository.deleteById(taskId);
//        } else {
//            throw new UnauthorizedAccessException("Only admins can delete tasks.");
//        }
//    }
//}
