package com.example.proj.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.proj.Entity.CalendarEvent;
import com.example.proj.Repo.CalendarEventRepository;

@Service
public class CalendarEventService 
{
	@Autowired
	private CalendarEventRepository calendareventrepository;
	
	public List<CalendarEvent> getAllCalendarEvents()
	{
		return calendareventrepository.findAll();
	}
	
	public Optional<CalendarEvent> getCalendarEventById(int id){
		return calendareventrepository.findById(id);
	}
	
	public CalendarEvent createCalendarEvent(CalendarEvent ce) {
		return calendareventrepository.save(ce);
	}
	
	public CalendarEvent updateCalendarEvent(int id,CalendarEvent ceDetails)
	{
		CalendarEvent event=calendareventrepository.findById(id).orElseThrow(()-> new RuntimeException("Event not found"));
		event.setUser_id(ceDetails.getUser_id());
		event.setAdmin_id(ceDetails.getAdmin_id());
		event.setEvent_title(ceDetails.getEvent_title());
		return calendareventrepository.save(event);
	}
	
	public void deleteCalendarEvent(int id) {
		calendareventrepository.deleteById(id);
	}
	
}
