package com.example.proj.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.proj.Entity.Admin;
import com.example.proj.Repo.AdminRepository;

@Service
public class AdminService 
{
	@Autowired
	private AdminRepository adminrepository;
	
	public List<Admin> getAllAdmin()
	{
		return adminrepository.findAll();
	}
	
	public Optional<Admin> getAdminById(int id)
	{
		return adminrepository.findById(id);
	}
	
	public Admin createAdmin(Admin admin)
	{
		return adminrepository.save(admin);
	}
	
	public Admin updateAdmin(int id, Admin admindetails)
	{
		Admin ad=adminrepository.findById(id).orElseThrow(()-> new RuntimeException("Admin not found"));
		ad.setName(admindetails.getName());
		ad.setEmail(admindetails.getEmail());
		ad.setPassword(admindetails.getPassword());
		ad.setDesignation(admindetails.getDesignation());
		return adminrepository.save(ad);
	}
	
	public void deleteAdmin(int id)
	{
		adminrepository.deleteById(id);
	}
}

