package com.example.proj.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.proj.Entity.Course;
import com.example.proj.Repo.CourseRepository;

import java.util.List;
import java.util.Optional;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;

    // Get all courses
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    // Get course by ID
    public Optional<Course> getCourseById(int courseId) {
        return courseRepository.findById(courseId);
    }

    // Add a new course
    public Course addCourse(Course course) {
        return courseRepository.save(course);
    }

    // Update an existing course
    public Course updateCourse(int courseId, Course courseDetails) {
        Course existingCourse = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        existingCourse.setCourse_name(courseDetails.getCourse_name());
        existingCourse.setSubjects(courseDetails.getSubjects());
        existingCourse.setCreated_by(courseDetails.getCreated_by());
        return courseRepository.save(existingCourse);
    }

    // Delete a course
    public void deleteCourse(int courseId) {
        courseRepository.deleteById(courseId);
    }
}
