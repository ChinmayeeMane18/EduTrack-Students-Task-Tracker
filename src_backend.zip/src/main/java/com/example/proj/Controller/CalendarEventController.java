package com.example.proj.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.proj.Entity.CalendarEvent;
import com.example.proj.Service.CalendarEventService;

@RestController
@RequestMapping("/events")
@CrossOrigin(origins = "http://localhost:5174") // Allow requests from React dev server
public class CalendarEventController 
{
	@Autowired
	private CalendarEventService calendereventservice;
	
	@GetMapping
	public List<CalendarEvent> getAllCalenderEvents()
	{
		return calendereventservice.getAllCalendarEvents();
	}
	
	@GetMapping("/{id}")
	public Optional<CalendarEvent> getCalendarEventById(@PathVariable int id)
	{
		return calendereventservice.getCalendarEventById(id);
	}
	
	@PostMapping
	public CalendarEvent createCalendarEvent(@RequestBody CalendarEvent ce)
	{
		return calendereventservice.createCalendarEvent(ce);
	}
	
	@PutMapping("/{id}")
	public CalendarEvent updateCalendarEvent(@PathVariable int id, @RequestBody CalendarEvent ceDetails)
	{
		return calendereventservice.updateCalendarEvent(id, ceDetails);
	}
	
	@DeleteMapping("/{id}")
	public void deleteCalendarEvent(@PathVariable int id)
	{
		calendereventservice.deleteCalendarEvent(id);
	}

}
