package com.example.proj.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.proj.Entity.Course;
import com.example.proj.Service.CourseService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/courses")
@CrossOrigin(origins = "http://localhost:5174") // Allow requests from React dev server
public class CourseController {

    @Autowired
    private CourseService courseService;

    // Get all courses (for both students and admins)
    @GetMapping
    public List<Course> getAllCourses() {
        return courseService.getAllCourses();
    }

    // Get course by ID (for both students and admins)
    @GetMapping("/{courseId}")
    public Optional<Course> getCourseById(@PathVariable int courseId) {
        return courseService.getCourseById(courseId);
    }

    // Add a new course (Admin only)
    @PostMapping
    public Course addCourse(@RequestBody Course course) {
        return courseService.addCourse(course);
    }

    // Update a course (Admin only)
    @PutMapping("/{courseId}")
    public Course updateCourse(@PathVariable int courseId, @RequestBody Course course) {
        return courseService.updateCourse(courseId, course);
    }

    // Delete a course (Admin only)
    @DeleteMapping("/{courseId}")
    public void deleteCourse(@PathVariable int courseId) {
        courseService.deleteCourse(courseId);
    }
}
