package com.example.proj.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.proj.Entity.Task;
import com.example.proj.Service.TaskService;

@RestController
@RequestMapping("/tasks")
@CrossOrigin(origins = "http://localhost:5174") // Allow requests from React dev server
public class TaskController {

    @Autowired
    private TaskService taskService;

    // Allow ALL users (ADMIN + STUDENT) to view tasks
    @GetMapping
    public List<Task> getAllTasks() {
        return taskService.getAllTasks();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Task> getTaskById(@PathVariable Long id) {
        Optional<Task> task = taskService.getTaskById(id);
        return task.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Task> createTask(@RequestBody Task task) {
        return ResponseEntity.ok(taskService.createTask(task));
    }

 // ✅ Allow ONLY ADMINS to update a task
    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Task> updateTask(@PathVariable Long id, @RequestBody Task updatedTask) {
        return ResponseEntity.ok(taskService.updateTask(id, updatedTask));
    }

    // ✅ Allow ONLY ADMINS to delete a task
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
        return ResponseEntity.ok("Task deleted successfully");
    }

    @PostMapping("/{id}/start")
    public ResponseEntity<Task> startTask(@PathVariable Long id) {
        Task task = taskService.startTask(id);
        return task != null ? ResponseEntity.ok(task) : ResponseEntity.notFound().build();
    }

    @PostMapping("/{id}/complete")
    public ResponseEntity<Task> completeTask(@PathVariable Long id) {
        Task task = taskService.completeTask(id);
        return task != null ? ResponseEntity.ok(task) : ResponseEntity.notFound().build();
    }
}


//@RestController
//@RequestMapping("/api/tasks")
//public class TaskController {
//
//    @Autowired
//    private TaskService taskService;
//
//    // ✅ Students can only view tasks
//    @GetMapping("/students/{userId}")
//    public ResponseEntity<List<Task>> getTasksForStudent(@PathVariable Long userId) {
//        return ResponseEntity.ok(taskService.getAllTasks(userId));
//    }
//
//    // ✅ Admins can view tasks
//    @GetMapping("/admin")
//    public ResponseEntity<List<Task>> getTasksForAdmin() {
//        return ResponseEntity.ok(taskService.getAllTasksForAdmin());
//    }
//
//    // ✅ Only Admins can add tasks
//    @PostMapping("/admin/{adminId}")
//    public ResponseEntity<Task> addTask(@PathVariable Long adminId, @RequestBody Task task) {
//        return ResponseEntity.ok(taskService.addTask(adminId, task));
//    }
//
//    // ✅ Only Admins can update tasks
//    @PutMapping("/admin/{adminId}/{taskId}")
//    public ResponseEntity<Task> updateTask(@PathVariable Long adminId, @PathVariable Long taskId, @RequestBody Task task) {
//        return ResponseEntity.ok(taskService.updateTask(adminId, taskId, task));
//    }
//
//    // ✅ Only Admins can delete tasks
//    @DeleteMapping("/admin/{adminId}/{taskId}")
//    public ResponseEntity<String> deleteTask(@PathVariable Long adminId, @PathVariable Long taskId) {
//        taskService.deleteTask(adminId, taskId);
//        return ResponseEntity.ok("Task deleted successfully.");
//    }
//}
