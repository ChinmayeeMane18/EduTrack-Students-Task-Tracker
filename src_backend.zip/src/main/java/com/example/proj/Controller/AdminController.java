package com.example.proj.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.proj.Entity.Admin;
import com.example.proj.Service.AdminService;


@RestController
@RequestMapping("/admins")
public class AdminController 
{
	@Autowired
	private AdminService adminservice;
	
	@GetMapping
	public List<Admin> getAllAdmin()
	{
		return adminservice.getAllAdmin();
	}
	@GetMapping("/{id}")
	public Optional<Admin> getAdminById(@PathVariable Integer id) 
	{
	    return adminservice.getAdminById(id);
	}
	
	@PostMapping
	public Admin createAdmin(@RequestBody Admin admin)
	{
		return adminservice.createAdmin(admin);
	}
	
	@PutMapping("/{id}")
	public Admin updateAdmin(@PathVariable int id, @RequestBody Admin admindetails)
	{
		return adminservice.updateAdmin(id, admindetails);
	}
	
	@DeleteMapping("/{id}")
	public void deleteAdmin(@PathVariable int id)
	{
		adminservice.deleteAdmin(id);
	}
}
