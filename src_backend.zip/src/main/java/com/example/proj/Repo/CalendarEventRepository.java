package com.example.proj.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.proj.Entity.CalendarEvent;

public interface CalendarEventRepository extends JpaRepository<CalendarEvent, Integer>
{

}
