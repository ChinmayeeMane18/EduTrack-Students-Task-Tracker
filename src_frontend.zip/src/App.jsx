import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import LandingPage from "./pages/LandingPage";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AdminDashboard from "./context/admin/AdminDashboard";
import CourseManagement from "./context/admin/CourseManagement";
import TaskManagement from "./context/admin/TaskManagement";
import StudentDashboard from "./context/Student/StudentDashboard";
import CourseSelection from "./context/Student/CourseSelection";
import TaskTable from "./context/Student/TaskTable";
import EventManager from "./context/admin/EventManager";

function App() {
  return (
    <Router>
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/courseManagement" element={<CourseManagement />} />
            <Route path="/taskManagement" element={<TaskManagement />} />
            <Route path="/student" element={<StudentDashboard />} />
            <Route path="/courses" element={<CourseSelection />} />
            <Route path="/taskTable " element={<TaskTable />} />
            <Route path="/event" element={<EventManager />} />

          </Routes>
        </main>
        <Footer />
        <Toaster position="top-right" />
      </div>
    </Router>
  );
}

export default App;
