import React, { useEffect, useState } from 'react';
import axios from 'axios';

const CourseManagement = () => {
  const [courses, setCourses] = useState([]);
  const [editingCourse, setEditingCourse] = useState(null);
  const [courseName, setCourseName] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    try {
      const response = await axios.get('http://localhost:9099/courses');
      setCourses(response.data);
    } catch (error) {
      console.error('Error fetching courses:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const course = { courseName, description };

    try {
      if (editingCourse) {
        await axios.put(`http://localhost:9099/courses/${editingCourse.courseId}`, course);
      } else {
        await axios.post('http://localhost:9099/courses', course);
      }
      setCourseName('');
      setDescription('');
      setEditingCourse(null);
      fetchCourses();
    } catch (error) {
      console.error('Error saving course:', error);
    }
  };

  const deleteCourse = async (courseId) => {
    try {
      await axios.delete(`http://localhost:9099/courses/${courseId}`);
      fetchCourses();
    } catch (error) {
      console.error('Error deleting course:', error);
    }
  };

  const editCourse = (course) => {
    setEditingCourse(course);
    setCourseName(course.courseName);
    setDescription(course.description);
  };

  return (
    <div>
      <h1>Course Management</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Course Name"
          value={courseName}
          onChange={(e) => setCourseName(e.target.value)}
        />
        <input
          type="text"
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <button type="submit">{editingCourse ? 'Update' : 'Add'} Course</button>
      </form>
      <ul>
        {courses.map(course => (
          <li key={course.courseId}>
            <strong>{course.courseName}</strong> - {course.description}
            <button onClick={() => editCourse(course)}>Edit</button>
            <button onClick={() => deleteCourse(course.courseId)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CourseManagement;
