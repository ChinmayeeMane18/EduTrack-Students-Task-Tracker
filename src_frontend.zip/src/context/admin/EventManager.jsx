import React, { useState, useEffect } from "react";
import axios from "axios";
import "./EventManager.css";

const EventManager = () => {
  const [events, setEvents] = useState([]);
  const [formData, setFormData] = useState({ id: "", title: "", date: "" });
  const [isEditing, setIsEditing] = useState(false);

  // Fetch all events on component mount
  useEffect(() => {
    fetchEvents();
  }, []);

  // Fetch events from the backend
  const fetchEvents = async () => {
    try {
      const response = await axios.get("http://localhost:9099/events");
      setEvents(response.data);
    } catch (error) {
      console.error("Error fetching events:", error);
    }
  };

  // Create a new event
  const createEvent = async () => {
    try {
      const eventData = {
        admin_id: 1,  // Provide a valid admin_id
        user_id: 2,   // Provide a valid user_id
        event_title: formData.title,
        event_date: formData.date,
      };
  
      const response = await axios.post("http://localhost:9099/events", eventData);
      setEvents([...events, response.data]);
      resetForm();
    } catch (error) {
      console.error("Error creating event:", error.response?.data || error.message);
    }
  };
  

  // Update an existing event
  const updateEvent = async () => {
    try {
      const updatedEventData = {
        admin_id: 1,  
        user_id: 8,   
        event_title: formData.title,
        event_date: formData.date,
      };
  
      const response = await axios.put(
        `http://localhost:9099/events/${formData.id}`,
        updatedEventData
      );
      setEvents(events.map((event) => (event.event_id === formData.id ? response.data : event)));
      resetForm();
    } catch (error) {
      console.error("Error updating event:", error.response?.data || error.message);
    }
  };
  

  // Delete an event
  const deleteEvent = async (id) => {
    try {
      await axios.delete(`http://localhost:9099/events/${id}`);
      setEvents(events.filter((event) => event.id !== id));
    } catch (error) {
      console.error("Error deleting event:", error);
    }
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (isEditing) {
      updateEvent();
    } else {
      createEvent();
    }
  };

  // Reset the form and editing state
  const resetForm = () => {
    setFormData({ id: "", title: "", date: "" });
    setIsEditing(false);
  };

  // Handle editing an event
  const handleEdit = (event) => {
    setIsEditing(true);
    setFormData({
      id: event.event_id,  // Make sure this matches your database ID field
      title: event.event_title,
      date: event.event_date,
    });
  };
  

  return (
    <div>
      <h1>Calendar Event Manager</h1>

      {/* Event Form */}
      <form onSubmit={handleSubmit}>
        <h2>{isEditing ? "Edit Event" : "Create Event"}</h2>
        <input
          type="text"
          placeholder="Event Title"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          required
        />
        <input
          type="date"
          value={formData.date}
          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
          required
        />
        <button type="submit">{isEditing ? "Update" : "Create"}</button>
        {isEditing && <button type="button" onClick={resetForm}>Cancel</button>}
      </form>

      {/* Event List */}
      <div>
        <h2>Event List</h2>
        <ul>
          {events.map((event) => (
            <li key={event.id}>
              <strong>{event.title}</strong> - {event.date}
              <button onClick={() => handleEdit(event)}>Edit</button>
              <button onClick={() => deleteEvent(event.id)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default EventManager;
