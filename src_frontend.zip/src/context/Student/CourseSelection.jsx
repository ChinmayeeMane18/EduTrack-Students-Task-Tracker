import React from "react";
import "./CourseSelection.css";

const CourseSelection = () => {
  const courses = [
    {
      id: 1,
      name: "DAC",
      subjects:
        "Operating Systems, OOPS, Data Structures, DBMS, Java, Web Technologies",
    },
    {
      id: 2,
      name: "DBDA",
      subjects:
        "Data Science, Machine Learning, SQL, Big Data, AI, Cloud Computing",
    },
    {
      id: 3,
      name: "DASSD",
      subjects:
        "Software Engineering, Web Development, Full Stack Development, Java, DevOps",
    },
    {
      id: 4,
      name: "DVLSI",
      subjects:
        "VLSI Design, Semiconductor Technology, Digital Electronics, FPGA",
    },
    {
      id: 5,
      name: "DESD",
      subjects:
        "Embedded Systems, Microcontrollers, IoT, Real-Time Systems",
    },
  ];

  return (
    <div className="course-selection">
      <h1><b>Our Courses</b></h1>
      <div className="courses-grid">
        {courses.map((course) => (
          <div key={course.id} className="course-card">
            <h3>{course.name}</h3>
            <p><strong>Subjects:</strong> {course.subjects}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CourseSelection;
