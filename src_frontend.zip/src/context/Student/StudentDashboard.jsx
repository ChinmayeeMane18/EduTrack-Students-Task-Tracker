import React from "react";
import "./StudentDashboard.css";

const StudentDashboard = () => {
  return (
    <div className="student-dashboard">
      <h2>Welcome, Student!</h2>
      <div className="dashboard-cards">
        <div className="card">
          <h3>Current Courses</h3>
          <p>5 Active Courses</p>
        </div>
        <div className="card">
          <h3>Pending Tasks</h3>
          <p>4 Tasks Due</p>
        </div>
        <div className="card">
          <h3>Progress</h3>
          <p>40% Complete</p>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
