import React from "react";
import "./TaskTable.css";

const TaskTable = () => {
  const tasks = [
    { id: 1, name: "Assignment 1", dueDate: "2024-11-20", status: "Pending" },
    {
      id: 2,
      name: "Project Overviwe",
      dueDate: "2024-01-25",
      status: "Completed",
    },
    { id: 3, name: "Final project", dueDate: "2025-03-10", status: "Pending" },
  ];

  return (
    <div className="task-table">
      <h2>My Tasks</h2>
      <table>
        <thead>
          <tr>
            <th>Task Name</th>
            <th>Due Date</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((task) => (
            <tr key={task.id}>
              <td>{task.name}</td>
              <td>{task.dueDate}</td>
              <td>
                <span className={`status ${task.status.toLowerCase()}`}>
                  {task.status}
                </span>
              </td>
              <td>
                <button className="view-btn">View</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TaskTable;
